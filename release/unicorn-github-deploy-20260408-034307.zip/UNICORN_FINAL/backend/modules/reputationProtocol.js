class ReputationProtocol {
  constructor() {
    this.entities = new Map();
    this.reviewQueue = [];
    this.blockchain = [];
  }

  registerEntity(entityId, type, metadata = {}) {
    if (this.entities.has(entityId)) throw new Error('Entity already registered');
    const entity = {
      id: entityId,
      type,
      metadata,
      score: 0.5,
      confidence: 0.5,
      history: [],
      reviews: [],
      transactions: [],
      registeredAt: new Date().toISOString(),
      lastUpdated: new Date().toISOString()
    };
    this.entities.set(entityId, entity);
    this.addToBlockchain({ action: 'register', entityId, type, timestamp: new Date().toISOString() });
    return entity;
  }

  verifyReview(reviewerId, targetId, metadata) {
    const reviewer = this.entities.get(reviewerId);
    const hasTransaction = reviewer && reviewer.transactions.some(t => t.counterparty === targetId);
    return hasTransaction || (metadata && metadata.hasTransaction === true);
  }

  addReview(reviewerId, targetId, rating, comment, metadata = {}) {
    if (!this.entities.has(reviewerId)) throw new Error('Reviewer not registered');
    if (!this.entities.has(targetId)) throw new Error('Target not registered');
    if (rating < 1 || rating > 5) throw new Error('Rating must be between 1 and 5');

    const review = {
      id: Date.now() + '-' + Math.random().toString(36),
      reviewerId,
      targetId,
      rating,
      comment,
      metadata,
      timestamp: new Date().toISOString(),
      verified: this.verifyReview(reviewerId, targetId, metadata)
    };

    const target = this.entities.get(targetId);
    target.reviews.push(review);
    target.lastUpdated = new Date().toISOString();
    this.updateReputationScore(targetId);
    this.addToBlockchain({ action: 'review', reviewId: review.id, targetId, rating, timestamp: review.timestamp });
    return review;
  }

  updateReputationScore(entityId) {
    const entity = this.entities.get(entityId);
    if (!entity) return;
    const reviews = entity.reviews;
    if (!reviews.length) {
      entity.score = 0.5;
      entity.confidence = 0.5;
      return;
    }
    const alpha = 1 + reviews.reduce((sum, r) => sum + (r.rating - 1), 0);
    const beta = 1 + reviews.reduce((sum, r) => sum + (5 - r.rating), 0);
    entity.score = alpha / (alpha + beta);
    entity.confidence = Math.min(Math.sqrt(alpha + beta) / 10, 1);
  }

  recordTransaction(entityId, counterpartyId, amount, type = 'payment') {
    const entity = this.entities.get(entityId);
    const counterparty = this.entities.get(counterpartyId);
    if (!entity || !counterparty) throw new Error('Entity not found');
    const transaction = { id: Date.now() + '-' + Math.random().toString(36), entityId, counterparty: counterpartyId, amount, type, timestamp: new Date().toISOString() };
    entity.transactions.push(transaction);
    counterparty.transactions.push({ ...transaction, entityId: counterpartyId, counterparty: entityId });
    this.addToBlockchain({ action: 'transaction', transactionId: transaction.id, from: entityId, to: counterpartyId, amount });
    return transaction;
  }

  addToBlockchain(data) {
    const block = {
      index: this.blockchain.length + 1,
      timestamp: new Date().toISOString(),
      data,
      previousHash: this.blockchain.length ? this.blockchain[this.blockchain.length - 1].hash : '0',
      hash: this.calculateHash(this.blockchain.length + 1, data)
    };
    this.blockchain.push(block);
  }

  calculateHash(index, data) {
    const crypto = require('crypto');
    return crypto.createHash('sha256').update(String(index) + JSON.stringify(data)).digest('hex');
  }

  getReputation(entityId) {
    const entity = this.entities.get(entityId);
    if (!entity) return null;
    const ratingDistribution = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    for (const review of entity.reviews) ratingDistribution[review.rating] += 1;
    return { id: entity.id, type: entity.type, score: entity.score, confidence: entity.confidence, totalReviews: entity.reviews.length, ratingDistribution, recentReviews: entity.reviews.slice(-5), registeredAt: entity.registeredAt };
  }

  getTopEntities(limit = 10, type = null) {
    let entities = Array.from(this.entities.values());
    if (type) entities = entities.filter(e => e.type === type);
    entities.sort((a, b) => b.score - a.score);
    return entities.slice(0, limit).map(e => ({ id: e.id, type: e.type, score: e.score, confidence: e.confidence }));
  }

  getStats() {
    const entities = Array.from(this.entities.values());
    return {
      totalEntities: entities.length,
      averageScore: entities.reduce((sum, e) => sum + e.score, 0) / (entities.length || 1),
      totalReviews: entities.reduce((sum, e) => sum + e.reviews.length, 0),
      totalTransactions: entities.reduce((sum, e) => sum + e.transactions.length, 0),
      blockchainHeight: this.blockchain.length
    };
  }
}

module.exports = new ReputationProtocol();
