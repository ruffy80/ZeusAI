const natural = require('natural');
const Sentiment = require('sentiment');
const sentiment = new Sentiment();

class AINegotiator {
  constructor() {
    this.strategies = {
      collaborative: "Let's find a win-win solution that benefits both parties.",
      competitive: "This is our final and best offer. Take it or leave it.",
      accommodating: "We value our partnership and can adjust to meet your needs.",
      compromising: "Let's meet in the middle to reach an agreement quickly."
    };

    this.activeNegotiations = new Map();
    this.negotiationId = 0;
  }

  analyzeMessage(text) {
    const analysis = sentiment.analyze(text);
    const tokenizer = new natural.WordTokenizer();
    const tokens = tokenizer.tokenize(text.toLowerCase());

    let intent = 'general';
    if (tokens.some(t => ['price', 'cost', 'budget', 'fee'].includes(t))) intent = 'price';
    if (tokens.some(t => ['deadline', 'time', 'delay'].includes(t))) intent = 'timeline';
    if (tokens.some(t => ['quality', 'feature', 'performance'].includes(t))) intent = 'quality';
    if (tokens.some(t => ['discount', 'deal', 'offer'].includes(t))) intent = 'discount';

    return {
      sentiment: { score: analysis.score, comparative: analysis.comparative },
      intent,
      tokens
    };
  }

  startNegotiation(params) {
    const { counterparty, topic, initialOffer, targetPrice, maxDiscount, deliveryTime } = params;
    const id = ++this.negotiationId;

    const negotiation = {
      id,
      counterparty,
      topic,
      initialOffer,
      targetPrice: targetPrice || initialOffer * 0.9,
      maxDiscount: maxDiscount || 10,
      deliveryTime: deliveryTime || '2-3 weeks',
      currentOffer: initialOffer,
      round: 0,
      status: 'active',
      history: [],
      startedAt: new Date().toISOString()
    };
    this.activeNegotiations.set(id, negotiation);
    return { id, startedAt: negotiation.startedAt };
  }

  async processMessage(negotiationId, message, userType = 'counterparty') {
    const negotiation = this.activeNegotiations.get(negotiationId);
    if (!negotiation) throw new Error('Negotiation not found');
    if (negotiation.status !== 'active') throw new Error('Negotiation is not active');

    const analysis = this.analyzeMessage(message);

    // Înregistrează în istoric
    negotiation.history.push({
      round: ++negotiation.round,
      userType,
      message,
      analysis,
      timestamp: new Date().toISOString()
    });

    let strategy = 'collaborative';
    if (analysis.sentiment.score < -2) strategy = 'accommodating';
    if (analysis.sentiment.score > 2) strategy = 'competitive';
    if (analysis.intent === 'price' && negotiation.round > 2) strategy = 'compromising';

    let response = this.strategies[strategy];

    if (analysis.intent === 'price') {
      const step = (negotiation.targetPrice - negotiation.currentOffer) / (5 - negotiation.round);
      negotiation.currentOffer += step;
      response += ` Regarding the price, we propose ${negotiation.currentOffer.toFixed(2)} USD.`;
    }

    if (analysis.intent === 'discount') {
      response += ` We can offer up to ${negotiation.maxDiscount}% discount for bulk orders.`;
    }

    if (analysis.intent === 'timeline') {
      response += ` The estimated delivery time is ${negotiation.deliveryTime}.`;
    }

    let status = 'active';
    let finalAgreement = null;

    if (Math.abs(negotiation.currentOffer - negotiation.targetPrice) < 1 && negotiation.round > 2) {
      status = 'agreed';
      finalAgreement = {
        price: negotiation.currentOffer,
        terms: negotiation.topic,
        agreedAt: new Date().toISOString()
      };
      negotiation.status = 'completed';
    } else if (negotiation.round >= 10) {
      status = 'expired';
      negotiation.status = 'expired';
    }

    return { response, status, finalAgreement, round: negotiation.round };
  }

  getNegotiation(id) {
    const negotiation = this.activeNegotiations.get(id);
    if (!negotiation) return null;

    return {
      id: negotiation.id,
      counterparty: negotiation.counterparty,
      topic: negotiation.topic,
      currentOffer: negotiation.currentOffer,
      targetPrice: negotiation.targetPrice,
      round: negotiation.round,
      status: negotiation.status,
      history: negotiation.history.slice(-10),
      startedAt: negotiation.startedAt
    };
  }

  getStats() {
    const negotiations = Array.from(this.activeNegotiations.values());
    return {
      total: negotiations.length,
      active: negotiations.filter(n => n.status === 'active').length,
      completed: negotiations.filter(n => n.status === 'completed').length,
      expired: negotiations.filter(n => n.status === 'expired').length
    };
  }
}

module.exports = new AINegotiator();
